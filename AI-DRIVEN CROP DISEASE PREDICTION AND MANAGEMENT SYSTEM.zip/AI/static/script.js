let fileInput = document.getElementById("fileInput");
let selectedFile;

function handleFileSelect() {
  selectedFile = fileInput.files[0];
  document.getElementById("fileName").innerText = selectedFile.name;
}

function uploadImage() {
    if (!selectedFile) {
      alert("Please select an image first.");
      return;
    }
  
    const formData = new FormData();
    formData.append("file", selectedFile);
  
    // Hide the result box initially before upload
    let resultDiv = document.getElementById("result");
    if (resultDiv) {
      resultDiv.style.display = "none";  // Hide the result box
    }

    fetch("/predict", {
      method: "POST",
      body: formData,
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.error) {
          displayResult(`Error: ${data.error}`);
        } else {
          displayResult(` 
              ${data.recommendation}
          `);          
        }
      })
      .catch((err) => {
        console.error(err);
        displayResult(`An error occurred while uploading.`);
      });
}

function displayResult(htmlContent) {
    let resultDiv = document.getElementById("result");
    if (!resultDiv) {
      resultDiv = document.createElement("div");
      resultDiv.id = "result";
      document.body.appendChild(resultDiv);
    }

    resultDiv.innerHTML = htmlContent;
    resultDiv.style.display = "block";
    
    // Now make the result box visible after the result is updated
    resultDiv.style.display = "block";  // Show the result box
}